<h1 align="center">
  <br>
  <img src="icon/icon.webp" width="150"/>
  <br>
  Kanade
  <br>
</h1>
<h4 align="center">第三方网易云音乐客户端</h4>
<p align="center">
    <h4 align="center">本软件仅供学习交流使用  请勿用于其他用途<br /><br />下载后请在 24 小时内删除
</h4>
</p>


## Screenshot

<table>
  <tr>
    <td><img src="screenshot/Screenshot_1.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_2.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_3.jpg" width="200" /></td>
  </tr>
  <tr>
    <td><img src="screenshot/Screenshot_4.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_5.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_6.jpg" width="200" /></td>
  </tr>
  <tr>
    <td><img src="screenshot/Screenshot_7.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_8.jpg" width="200" /></td>
    <td><img src="screenshot/Screenshot_9.jpg" width="200" /></td>
  </tr>
</table>